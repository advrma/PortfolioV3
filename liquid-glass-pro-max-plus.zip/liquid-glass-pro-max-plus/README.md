# Liquid Glass Pro Max Plus

A Pen created on CodePen.

Original URL: [https://codepen.io/fand/pen/azmPjqd](https://codepen.io/fand/pen/azmPjqd).

