# 3D Globe Three.js with location pointer

A Pen created on CodePen.

Original URL: [https://codepen.io/ksenia-k/pen/NWERpmb](https://codepen.io/ksenia-k/pen/NWERpmb).

