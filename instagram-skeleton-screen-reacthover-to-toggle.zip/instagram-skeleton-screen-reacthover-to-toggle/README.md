# Instagram Skeleton Screen (React) - Hover to toggle!

A Pen created on CodePen.

Original URL: [https://codepen.io/andyNroses/pen/XxqoNe](https://codepen.io/andyNroses/pen/XxqoNe).

Here is my approach on skeleton screens using React and its wonderful conditional rendering!